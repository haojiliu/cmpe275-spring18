zmq_read_host = 'some read host'
read_client_port = 5559
zmq_write_host = '0.0.0.0'
write_port = 8081

# the sqlite db file, not mongo
DB_FILE_PATH = '/srv/tmp.db'
